#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#include <windows.h>
#include "euph-win.h"

DWORD chan;	// the channel... HMUSIC or HSTREAM
//DWORD timer;

long escpressed = 0;

//unsigned        position=0;               /* Current position */
//unsigned        pattern=0;                /* Current pattern number */
//unsigned        row=0;                    /* Current row number */
//int             syncInfo=0;               /* Music synchronization info */

//Sprite Flare;
World *Scene;
World *Scenes[4];

/*short frames=0;
double Counter=0;
unsigned long Counter2=0,Counter3=0;
const float FPS = 30.0;
const double Increment = FPS / 100.0f;*/

//called 10ms delays, 100 times per second
void CALLBACK prevr(UINT uTimerID, UINT uMsg, DWORD dwUser, DWORD dw1, DWORD dw2)
{
/*  Counter += Increment;
  Scene->CurFrame = (Counter);
  Counter3++;
  Counter2++;
  frames++;*/
}

int precalc ()
{
	cout << "loading scenes..." << endl;
	Scenes[0] = Read3DS("henge4.3ds");
	Scenes[1] = Read3DS("laivassa.3ds");
	Scenes[2] = Read3DS("mauso3.3ds");
	Scenes[3] = Read3DS("scifi.3ds");
	
	if(Scenes[0] == NULL)
	{
		cout << "couldnt load henge4.3ds"<< endl;
		exit(0);
	}
	cout << "all loaded" << endl;
	return 0;
}

//int main(int argc, char **argv)
int main(HINSTANCE hInst, HINSTANCE prevHinst, LPSTR strCmdLine, INT nCmdShow)
{
	int CurScene = 0;
	cout << "-EUPHORIA by Pyrotech-" << endl;
	cout << "Lataa s�l�� muistiin eik� vapauta niit� koskaan..." << endl;

	//srand(43);

	if( precalc() )
	{
		cout << "Precalculation failed!" << endl;
		return 1;
	}

	// setup output - default device, 44100hz, stereo, 16 bits
/*	if (!BASS_Init(-1,44100,0, vesahwnd))
	{
		cout << "Can't initialize musicdevice" << endl;		//DestroyWindow(win);
		return 1;
	}
	BASS_Start();

	chan = BASS_MusicLoad(FALSE, "euphoria.xm", 0,0, BASS_MUSIC_RAMP);
	if(chan == 0)
	{
		cout << "loading music module failed" << endl;
		return 1;
	}*/
	
	/*timer = timeSetEvent(10, 10, (LPTIMECALLBACK)&prevr, 0, TIME_PERIODIC);
	//wintimer = timeSetEvent(250.0f, 100.0f, (LPTIMECALLBACK)&winmsgloop, 0, TIME_PERIODIC);

	if(timer == 0 )
	{
		exit(0);
	}

	BASS_MusicPlay(chan);
	UpdateInfo();*/

/* BASS_MusicPlay(chan);
 UpdateInfo();
 while(position<10) {
	 UpdateInfo();
 }*/
	
	/*SetupScene(Scenes[0],1,0,1,2000.0,10.0,1,1);
	Scenes[1] = Read3DS("laivassa.3ds");
	SetupScene(Scenes[1],1,1,0,256.0,8.0,0,0);
	Scenes[2] = Read3DS("mauso3.3ds");
	SetupScene(Scenes[2],0,0,0,2000.0,10.0,0,0);
	Scenes[3] = Read3DS("scifi.3ds");
	SetupScene(Scenes[3],0,0,1,1350.0,10.0,0,0);*/
    
  //cout << "asdhasda" << endl;
/*	lfb = SetVbeMode(320,200,32, hInst);
	if(lfb==NULL)
	{
		cout << "Osta parempi mopo!(ei tue moodia 320x200x32bpp)" << endl;
		return 0;
	}*/
/*	dblbuf = setvbedblbuf(lfb);
	VbeCls(dblbuf);
	blurscr = setvbedblbuf(lfb);
	VbeCls(blurscr);
	dblbuf2 = setvbedblbuf(lfb);
*/
    unsigned int flag = 28;

//    frames =  0; Counter = 0; Counter2 = 0; Counter3=0;
//    Scene->CurFrame = 0; //falku = 0;

//ostamopo:
	//while(1/*position<flag && Scene->CurFrame<Scene->NumFrames*/)// && !escpressed)
    {

/*		if(Scene->ClsScrEnabled)
			VbeCls(dblbuf);
*/
		//UpdateInfo();
/*

		for(int i=0;i<Scene->Numlights;i++)
		{
			Scene->olights[i].x = Scene->olights[i].pospath[Scene->CurFrame].x;
			Scene->olights[i].y = Scene->olights[i].pospath[Scene->CurFrame].y;
			Scene->olights[i].z = Scene->olights[i].pospath[Scene->CurFrame].z;
		}
		Scene->cameras[Scene->ActiveCamera].px =
		Scene->cameras[Scene->ActiveCamera].pospath[Scene->CurFrame].x;
		Scene->cameras[Scene->ActiveCamera].py =
		Scene->cameras[Scene->ActiveCamera].pospath[Scene->CurFrame].y;
		Scene->cameras[Scene->ActiveCamera].pz =
		Scene->cameras[Scene->ActiveCamera].pospath[Scene->CurFrame].z;
		Scene->cameras[Scene->ActiveCamera].tx =
		Scene->cameras[Scene->ActiveCamera].tgtpath[Scene->CurFrame].x;
		Scene->cameras[Scene->ActiveCamera].ty =
		Scene->cameras[Scene->ActiveCamera].tgtpath[Scene->CurFrame].y;
		Scene->cameras[Scene->ActiveCamera].tz =
		Scene->cameras[Scene->ActiveCamera].tgtpath[Scene->CurFrame].z;

		MakeCamMat(&Scene->cameras[Scene->ActiveCamera]);

		for(i=0;i<Scene->Numobjs;i++)
		{
			if(CurScene<2) {
				int result = ObjectCull(&Scene->objects[i],Scene->cameras[Scene->ActiveCamera].ViewMat,
					Scene->cameras[Scene->ActiveCamera].FarPlane,Scene->cameras[Scene->ActiveCamera].NearPlane);
				if( result == 1) continue;
			}*/
			/*if(CurScene==2)
			{
				if(i==(Scene->Numobjs-1))
				{
					RotateObject(&Scene->objects[i],0,8.0/256.0,0);
					FakeEnvMap = 1;
				}else FakeEnvMap = 0;
			}
			else*///FakeEnvMap = 0;

/*			PolygonCull(&Scene->objects[i], &Scene->cameras[Scene->ActiveCamera]);
			World_To_Camera(&Scene->objects[i], Scene->cameras[Scene->ActiveCamera].ViewMat);
			ClipToPlanes(&Scene->objects[i], Scene->cameras[Scene->ActiveCamera].FarPlane, Scene->cameras[Scene->ActiveCamera].NearPlane);
			if(Scene->RealLights)
				CalcLightAtVert(&Scene->objects[i], Scene, 0);
			Projection(&Scene->objects[i], Scene->RealLights, Scene->ZBuffer, Scene->cameras[Scene->ActiveCamera].NearPlane,FakeEnvMap);
		}*/

		//if(Scene->FlaresEnabled) DisplayFlares(Scene);

      //if(GetKeyState(25))
      //  Scene->ParticlesEnabled = (~Scene->ParticlesEnabled) & 0x0001;
		//if(Scene->ParticlesEnabled) DrawParticles(Scene);

		//if(Scene->ZFogEnabled) CalcFog(Scene);
//		clear((char *)Scene->ZBuffer,16000,64000*4);
//		VbeFlip(lfb,dblbuf);
	}
//	CloseVbe(1);
//	if (timer) timeKillEvent(timer);
/*	cout << "quitting: position" << position << endl;
	cout << "quitting: flag" << flag << endl;
	cout << "quitting: CurFrame" << Scene->CurFrame << endl;
	cout << "quitting: NumFrames" << Scene->NumFrames << endl;
*/	return 0;
}


/*void UpdateInfo()
{
	BASS_Update();
	QWORD res = BASS_ChannelGetPosition(chan); // LOWORD=order HIWORD=row

	position = res & 0x0000ffff;
	row = (res>>16) & 0x0000ffff;

	MSG msg;
	if( PeekMessage( &msg, vesahwnd, 0U, 0U, PM_REMOVE ) )
	{
		TranslateMessage( &msg );
		DispatchMessage( &msg );
	}
}*/


