#ifndef PT_EUPHORIA_WIN
#define PT_EUPHORIA_WIN

#include <mmsystem.h>
#include <stdio.h>
#include <iostream.h>
#include <time.h>

#include "bitmap.h"
//#include "effut.h"

#include "3dstruct.h"
#include "n3ds.h"
//#include "misc.h"
//#include "3d.h"
//#include "part.h"

//#include "bass.h"

/*void SetupScene(World *Scene,short RealLights,short ZFogEnabled,short FlaresEnabled,float FarPlane,float NearPlane,short ClsScrEnabled,short ParticlesEnabled);
void SetupParticles(World *Scene,int NumF,int NumP,float XPos,float YPos,float ZPos);
void CalcFogTable(bits_24 *fogtable);
void CalcFog(World *Scene);
void DisplayFlares(World *Scene);
void DrawParticles(World *Scene);*/
//void UpdateInfo();
/*int DoBump(void);
long vesabump( BUMPSTRUCT * param1 );*/

/*void SetupScene(World *Scene,short RealLights,short ZFogEnabled,short FlaresEnabled,float FarPlane,float NearPlane,short ClsScrEnabled,short ParticlesEnabled);
void SetupParticles(World *Scene,int NumF,int NumP,float XPos,float YPos,float ZPos);

int XFadePic(PICTURE *Pic,long Shade);
*/

inline void clear(char *what,int col,int len) {
	__asm {
		mov edi, what;
		mov eax, col;
		mov ecx, len;
		mov dx, ax;
		shl eax,16;
		mov ax, dx;
		shr ecx, 2;
		cld;
		rep stosd;
	}
}

//VBESURFACE *blurscr;
//VBESURFACE *dblbuf;
//VBESURFACE *lfb;

#endif
