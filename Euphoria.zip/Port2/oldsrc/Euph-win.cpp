#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#include <windows.h>
#include "euph-win.h"

DWORD chan;	// the channel... HMUSIC or HSTREAM
DWORD timer;

long escpressed = 0;

unsigned char * pmapshadet;//[256*256];
unsigned char * multbl;//[64*64*64]; 
unsigned char * Clip0_256;//[1024];
int HomoNaama = 0;

long* dist;//[320*201];
long* st;//[65536];


char            moduleName[] = "euphoria.xm";

unsigned        position=0;               /* Current position */
unsigned        pattern=0;                /* Current pattern number */
unsigned        row=0;                    /* Current row number */
int             syncInfo=0;               /* Music synchronization info */

long PicShade1=0;
long PicShade2=0;

Sprite Flare;
World *Scene;
World *Scenes[4];

short frames=0;
double Counter=0;
unsigned long Counter2=0,Counter3=0;
const float FPS = 30.0;
const double Increment = FPS / 100.0f;

//called 10ms delays, 100 times per second
void CALLBACK prevr(UINT uTimerID, UINT uMsg, DWORD dwUser, DWORD dw1, DWORD dw2)
{
  Counter += Increment;
  Scene->CurFrame = (Counter);
  Counter3++;
  Counter2++;
  frames++;
}

int CurPic=0;

PICTURE *Creds[4];
PICTURE *EndPic;
PICTURE *EuphSel;
PICTURE *Dnaama;
PICTURE *Greets;
PICTURE *Demologo;
PICTURE *Demolog;
PICTURE *GreLogo;
PICTURE *Greets1;
PICTURE *Greets2;

VBESURFACE * dblbuf2;

//mulju
ROTZOOM * rotzoom;
CARDSPLINE * Spln, *Spln2, *Spln3, *Spln4, *Spln5, *Spln6;
PICTURE * pic;
PICTURE * texture, *texture2, *texture3;
PICTURE txtr, txtr2;
FDTUNNEL Tunnel;
GRID * Grid, *Grid2;

int precalc ()
{
	pmapshadet = new unsigned char[256*256];
	multbl = new unsigned char[64*64*64]; 
	Clip0_256 = new unsigned char[1024];

	dist = new long[320*201];
	st = new long[65536];

	cout << "loading scenes..." << endl;
	Scenes[0] = Read3DS("henge4.3ds");
	
	if(Scenes[0] == NULL)
	{
		cout << "couldnt load henge4.3ds"<< endl;
		exit(0);
	}

	cout << "loading textures..." << endl;
	texture  = LoadPCX("silsav.pcx",320,200,32);
	texture2 = LoadPCX("inho.pcx",320,200,32);
	texture3 = LoadPCX("kaytava2.pcx",320,200,32);
	if(texture == NULL || texture2 == NULL || texture3 == NULL) {cout<<"failed"<<endl; exit(0);}

	cout << "loading textures2..." << endl;
	Dnaama = LoadTGA("dnaama.tga");
	ChangePicture(Dnaama,320,200,32);
	PICTURE * EndPic = LoadTGA("endpic.tga");
	ChangePicture(EndPic,320,200,32);
	PICTURE *EuphSel = LoadTGA("euphsel.tga");
	ChangePicture(EuphSel,320,200,32);

	if(Dnaama == NULL || EndPic == NULL || EuphSel == NULL)
	{
		cout << "failed1" << endl; exit(0);
	}

	PICTURE * EuphLog = LoadPCX("euph.pcx",320,200,8);
	Creds[0] = LoadPCX("code.pcx",320,200,8);
	Creds[1] = LoadPCX("gfx.pcx",320,200,8);
	Creds[2] = LoadPCX("music.pcx",320,200,8);
	Creds[3] = LoadPCX("3dgfx.pcx",320,200,8);
	if(EuphLog == NULL || Creds[0] == NULL || Creds[1] == NULL || Creds[2] == NULL || Creds[3] == NULL)
	{
		cout << "failed2" << endl; exit(0);
	}

	//PICTURE *Pic1 = Creds[CurPic],*Pic2 = Creds[CurPic+1];
	//Greets = LoadPCX("greets.pcx",320,200,32);
	Demolog  = LoadPCX("demolog.pcx",320,200,32);
	GreLogo  = LoadPCX("grelog.pcx",320,200,32);;
	Greets1  = LoadPCX("part1.pcx",320,200,32);;
	Greets2  = LoadPCX("part2.pcx",320,200,32);;
	pic = new PICTURE; pic->ptr32 = dblbuf->ptr32; pic->Width  = dblbuf->Width; pic->Height = dblbuf->Height; pic->Bits = 32L;

	if(Demolog == NULL || GreLogo == NULL || Greets1 == NULL || Greets2 == NULL)
	{
		cout << "failed3" << endl; exit(0);
	}

	for(long u=0; u<64; u++)
		for(long uu=0; uu<64; uu++)
			for(long i=0;  i<64;  i++)
				multbl[(i<<12)+(uu<<6)+u] = ((uu*i + u*(64-i)) >>6) *4;

	// Spln  = Scalefactor         , rotangle      , zoomangle
	// Spln2 = (Scene <-> texture1), rottwistvoima , zoomtwistvoima
	// Spln3 = (txtr1 <-> txtr2)   , (mulju<->tun) ,
	// Spln4 = tunnelxorigin       , tunnelyorigin , tunnelzorigin
	// Spln5 = tunnelxangle        , tunnelyangle  , tunnelzangle
	// Spln6 = Scaleangdiff        ,               ,

	cout << "creating splines..." << endl;
	/*CARDSPLINE * */Spln  = CreateSpline(30,60,    256, 32768,   32768,     0,  0);
	/*CARDSPLINE * */Spln2 = CreateSpline(15,30,    256, 64*256,  64*256,    0,  0);
	/*CARDSPLINE * */Spln3 = CreateSpline(20,60,    544, 768,     256,   20*30,  0);
	/*CARDSPLINE * */Spln4 = CreateSpline(40,30,    288, 288,    1536,   20*30,  0);
	/*CARDSPLINE * */Spln5 = CreateSpline(10,120, 65536, 65536,  65536,  20*30,  0);
	/*CARDSPLINE * */Spln6 = CreateSpline(15,30,    256,     2,   2,     0,  0);
 
	for(long i=0; i<20; i++)
	{
		long jee = Spln3->Keys[i].x - 32;
		if( jee <= 0) Spln3->Keys[i].x = 0;
	//  else if( jee > 255) Spln3->Keys[i].x = 255;
		else Spln3->Keys[i].x = jee;
		jee = Spln3->Keys[i].y - 256;
		if( jee < -10) Spln3->Keys[i].y = -10;
		if( jee > 255) Spln3->Keys[i].y = 255;
		else Spln3->Keys[i].y = jee;
	}

	Spln3->Keys[0].x = -10;  Spln3->Keys[0].y = 300;
	Spln->Keys[0].x = 1.0*256; Spln2->Keys[0].x = 0;
	Spln->Keys[1].x = 1.0*256; Spln2->Keys[1].x = 0;
	Spln->Keys[2].x = 1.1*256; Spln2->Keys[2].x = 32;
	Spln->Keys[3].x = 1.0*256; Spln2->Keys[3].x = 6;
	Spln->Keys[4].x = 1.5*256; Spln2->Keys[4].x = 128;
	Spln->Keys[5].x = 1.1*256; Spln2->Keys[5].x = 32;
	Spln->Keys[6].x = 1.0*256; Spln2->Keys[6].x = 0;
	Spln->Keys[7].x = 1.0*256; Spln2->Keys[7].x = 64;
	Spln->Keys[8].x = 1.0*256; Spln2->Keys[8].x = 16;
	Spln->Keys[9].x = 1.2*256; Spln2->Keys[9].x = 290;
	Spln->Keys[10].x= 1.6*256; Spln2->Keys[10].x= 266;
	Spln->Keys[11].x= 1.5*256; Spln2->Keys[11].x= 266;
	Spln->Keys[12].x= 1.2*256; Spln2->Keys[12].x= 266;
	Spln->Keys[13].x= 1.5*256; Spln2->Keys[13].x= 266;
	Spln->Keys[14].x= 1.5*256; Spln2->Keys[14].x= 266;  

	Spln6->Keys[0].x = 0.0*256;
	Spln6->Keys[1].x = 0.0*256;
	Spln6->Keys[2].x = 0.0*256;
	Spln6->Keys[3].x = 0.0*256;
	Spln6->Keys[4].x = 0.0*256;
	Spln6->Keys[5].x = 0.0*256;
	Spln6->Keys[6].x = 0.0*256;
	Spln6->Keys[7].x = 0.0*256;
	Spln6->Keys[8].x = 0.2*256;
	Spln6->Keys[9].x = 1.1*256;
	Spln6->Keys[10].x= 1.0*256;
	Spln6->Keys[11].x= 1.0*256;
	Spln6->Keys[12].x= 1.0*256;
	Spln6->Keys[13].x= 1.0*256;
	Spln6->Keys[14].x= 1.0*256;


	Spln->Keys[0].y =  0;     Spln2->Keys[0].y =  0*256;
							Spln2->Keys[1].y =  0*256;
	Spln->Keys[1].y=   0*256; Spln2->Keys[2].y =  0*256;
							Spln2->Keys[3].y =  0*256;
	Spln->Keys[2].y= 0.5*256; Spln2->Keys[4].y=-0.5*256;
							Spln2->Keys[5].y =  0*256;
	Spln->Keys[3].y =0.2*256; Spln2->Keys[6].y =0.1*256;
							Spln2->Keys[7].y =  0*256;
	Spln->Keys[4].y=-0.1*256; Spln2->Keys[8].y =  0*256;
							Spln2->Keys[9].y =  2*256;
	Spln->Keys[5].y = 32*256; Spln2->Keys[10].y=-24*256;
							Spln2->Keys[11].y= 32*256;
	Spln->Keys[6].y = 40*256; Spln2->Keys[12].y=  0*256;
							Spln2->Keys[13].y= 32*256;
	Spln->Keys[7].y =128*256; Spln2->Keys[14].y= 32*256;

	Spln->Keys[0].z =  0;     Spln2->Keys[0].z =  0*256;
							Spln2->Keys[1].z =  0*256;
	Spln->Keys[1].z=   0*256; Spln2->Keys[2].z =  0*256;
							Spln2->Keys[3].z =  0*256;
	Spln->Keys[2].z= 0.5*256; Spln2->Keys[4].z=- -1*256;
							Spln2->Keys[5].z =  0*256;
	Spln->Keys[3].z =  0*256; Spln2->Keys[6].z =  0*256;
							Spln2->Keys[7].z =  0*256;
	Spln->Keys[4].z =  0*256; Spln2->Keys[8].z =  1*256;
							Spln2->Keys[9].z = 48*256;
	Spln->Keys[5].z = 32*256; Spln2->Keys[10].z= 24*256;
							Spln2->Keys[11].z= 64*256;
	Spln->Keys[6].z = 48*256; Spln2->Keys[12].z= 32*256;
							Spln2->Keys[13].z= 48*256;
	Spln->Keys[7].z =192*256; Spln2->Keys[14].z= 64*256;
  
// Spln3->
  
	for(i=14; i<30; i++)
		Spln->Keys[i].x = 1.5f *256;

	for(long y=-100; y<101; y++)
	    for(long x=-160; x<160; x++)
			dist[(y+100)*320+(x+160)] = sqrt( x*x + y*y );
 
	long * st = new long[65536];
	for(i=0; i<65536; i++)
		st[i] = sin(3.1415f*i/32768.0f)*65536.0f;

	cout << "creating grids..." << endl;
	/*GRID * */Grid     = new GRID;
	Grid->Xsize     = 64;
	Grid->Ysize     = 27;
	Grid->NumXgrids = 41;
	Grid->NumYgrids = 26;
	Grid->pixel     = new GRIDPIXEL[Grid->Xsize*Grid->Ysize];

	/*GRID * */Grid2     = new GRID;
	Grid2->Xsize     = 64;
	Grid2->Ysize     = 27;
	Grid2->NumXgrids = 41;
	Grid2->NumYgrids = 26;
	Grid2->pixel     = new GRIDPIXEL[Grid2->Xsize*Grid2->Ysize];

	/*ROTZOOM * */rotzoom     = new ROTZOOM;
	rotzoom->rottwist     = 1;
	rotzoom->zoomtwist    = 1; 
	rotzoom->rottwistvoima = 0;
	rotzoom->zoomtwistvoima= 0;
	rotzoom->rotangle     = Spln->y;
	rotzoom->zoomangle    = Spln->z;
	rotzoom->scalefactor  = 1.0;
	rotzoom->scaleangdiff = 1.0;
	rotzoom->sint         = st;
	rotzoom->dist         = dist;
	rotzoom->width        = 0;
	rotzoom->height       = 0;
	rotzoom->grid         = Grid2;

	Tunnel.sint      = st;
	Tunnel.grid      = Grid;  
	Tunnel.origin[2] = 0;

	txtr.Width = 320; txtr.Height= 200; txtr.Bits  = 32; txtr.ptr32 = new unsigned long[320*200];
	txtr2.Width = 320; txtr2.Height= 200; txtr2.Bits  = 32; txtr2.ptr32 = new unsigned long[320*200];

	for(long loop1=0; loop1<256; loop1++)
	{
		Clip0_256[loop1    ] = 0;
		Clip0_256[loop1+256] = (unsigned char)loop1;
		Clip0_256[loop1+512] = (unsigned char)255;  
	}

	{ //  CardinalSpline Precalculations START
		//CarTable = new float *[1000];
		//for(i=0; i<1000; i++) CarTable[i] = new float[4];
		float tt = 0.75;
		float s = (1.0f - tt / 2.0f);
		double u = 0.0;
		for(i=0; i<1000; i++)
		{
			CarTable[i][0] = (-s*u*u*u + 2*s*u*u - s*u);
			CarTable[i][1] = ((2-s)*u*u*u + (s-3)*u*u + 1);
			CarTable[i][2] = ((s-2)*u*u*u + (3-2*s)*u*u + s*u);
			CarTable[i][3] = (s*u*u*u - s*u*u);
			u += 1.0f/1000.0f;
		} 
	} // CardinalSpline Precalculations END

	return 0;
}

int domulju ()
{
 rotzoom->scaleangdiff = 1.0;
//mulju:
  //Muljutusta
  while(position<42 && !escpressed)
  {
    escpressed = GetKeyState(VK_ESCAPE);
    UpdateInfo();
    long FrameNum = long(Counter)-1800;
    if(FrameNum<0) FrameNum=0;
      //goto ostamopo;
    UpdateSpline(Spln ,FrameNum);
    UpdateSpline(Spln2,FrameNum);
    UpdateSpline(Spln3,FrameNum);
    UpdateSpline(Spln4,FrameNum);
    UpdateSpline(Spln5,FrameNum);
    UpdateSpline(Spln6,FrameNum);
    PICTURE * morphed  = XFadeTextures(pic,     texture,  Spln2->x , &txtr);
    PICTURE * morphed2 = XFadeTextures(morphed, texture2, Spln3->x , &txtr2);
    PICTURE * morphed3 = XFadeTextures(morphed2,texture3, Spln3->x-256, &txtr2);
    Tunnel.origin[0] = Spln4->x-180.0f;
    Tunnel.origin[1] = Spln4->y-180.0f;
    Tunnel.origin[2] = Spln4->z-768.0f;
    Tunnel.XrotAng   = Spln5->x;
    Tunnel.YrotAng   = Spln5->y;
    Tunnel.ZrotAng   = Spln5->z;

    FdTunnel(&Tunnel);
    rotzoom->centerX = 0;
    rotzoom->centerY = 0;
    rotzoom->scalefactor    = Spln->x/256.0;
    rotzoom->scaleangdiff   = Spln6->x/256.0;
    rotzoom->rottwistvoima  = Spln2->y;
    rotzoom->zoomtwistvoima = Spln2->z;
    rotzoom->rotangle  = Spln->y;
    rotzoom->zoomangle = Spln->z;  
    RotateZoom2d(rotzoom,1);
    DrawGrid(Grid, Grid2, Spln3->y, morphed3, dblbuf2);

    if( FrameNum>=(8*30) && FrameNum<(16*30) ) {
      unsigned char a = (FrameNum-(8*30))*255/(8*30); // 0 -- 255
//          char ima = 255-a;
      unsigned long aoffs = (a>>2)<<12;
      for(int i=0;i<64000;i++) {
        if(Dnaama->ptr32[i]!=0) {
          unsigned char * cpic1  = (unsigned char *) &Dnaama->ptr32[i];
          unsigned char * cpic2  = (unsigned char *) &dblbuf2->ptr32[i];
          unsigned char b=multbl[aoffs+((cpic1[0]>>2)<<6)+(cpic2[0]>>2)];
          unsigned char g=multbl[aoffs+((cpic1[1]>>2)<<6)+(cpic2[1]>>2)];
          unsigned char r=multbl[aoffs+((cpic1[2]>>2)<<6)+(cpic2[2]>>2)];

          dblbuf2->ptr32[i] = (r<<16)+(g<<8)+b;
        }
      }
    }
    if(FrameNum>=16*30) 
      for(int i=0;i<64000;i++) {if(Dnaama->ptr32[i]!=0)
          dblbuf2->ptr32[i] = Dnaama->ptr32[i];}

    VbeFlip(lfb, dblbuf2);

    if(position>=26 && position<28) return 0;//goto ostamopo;

  }
  if(escpressed) exit(0);//goto loppu;	return 0;
  return 0;
}

//int main(int argc, char **argv)
int main(HINSTANCE hInst, HINSTANCE prevHinst, LPSTR strCmdLine, INT nCmdShow)
{
	int CurScene = 0;
	cout << "-EUPHORIA by Pyrotech-" << endl;
	cout << "Lataa s�l�� muistiin eik� vapauta niit� koskaan..." << endl;

	srand(43);

	if( precalc() )
	{
		cout << "Precalculation failed!" << endl;
		return 1;
	}

//	unsigned short aste=0;
	//setbuf(stdout, NULL);

	// setup output - default device, 44100hz, stereo, 16 bits
	if (!BASS_Init(-1,44100,0, vesahwnd))
	{
		cout << "Can't initialize musicdevice" << endl;		//DestroyWindow(win);
		return 1;
	}
	BASS_Start();

	chan = BASS_MusicLoad(FALSE, "euphoria.xm", 0,0, BASS_MUSIC_RAMP);
	if(chan == 0)
	{
		cout << "loading music module failed" << endl;
		return 1;
	}

/* BASS_MusicPlay(chan);
 UpdateInfo();
 while(position<10) {
	 UpdateInfo();
 }*/
	
	/*SetupScene(Scenes[0],1,0,1,2000.0,10.0,1,1);
	Scenes[1] = Read3DS("laivassa.3ds");
	SetupScene(Scenes[1],1,1,0,256.0,8.0,0,0);
	Scenes[2] = Read3DS("mauso3.3ds");
	SetupScene(Scenes[2],0,0,0,2000.0,10.0,0,0);
	Scenes[3] = Read3DS("scifi.3ds");
	SetupScene(Scenes[3],0,0,1,1350.0,10.0,0,0);*/
    
	CurScene = 0;
	Scene = Scenes[CurScene];

	// PARTIKKELI FLARE
	/*Flare.Buffer = LoadPicture("flare5.tga");
	Flare.XLen = 64; Flare.YLen = 64;
	ChangePicture(Flare.Buffer,64,64,32);

	for(i=2; i<2000; i++) {
		coefftable[i] = (256.0 / i)*256;
	} 
	const short frameSpeed=FPS;
	const short msPerFrame=1000/frameSpeed;*/

	/*short actFrames=0;
	short actFps=0;
	short skipFrames=0;
	short fps=0;
	unsigned long fpsCounter;
	unsigned long speedCounter;
	fpsCounter=speedCounter=Counter2=0;*/

	//unsigned long temp=Counter2=0;
	//unsigned falku = 0;

/*  if ( !MIDASinit() )
       MIDASerror();
  if ( (module = MIDASloadModule(moduleName)) == NULL )
        MIDASerror();*/

  //cout << "asdhasda" << endl;
	lfb = SetVbeMode(320,200,32, hInst);
	if(lfb==NULL)
	{
		cout << "Osta parempi mopo!(ei tue moodia 320x200x32bpp)" << endl;
		return 0;
	}
	dblbuf = setvbedblbuf(lfb);
	VbeCls(dblbuf);
	blurscr = setvbedblbuf(lfb);
	VbeCls(blurscr);
	dblbuf2 = setvbedblbuf(lfb);

/*  set_screenw(320);
  set_screenh(200);
  set_screenbpp(32);
  set_screen(dblbuf->ptr32);

  font *blue=new font("fonts.pcx");
  blue->update_on();
*/  int FakeEnvMap = 0;
    unsigned int flag = 28;

    if(DoBump()) exit(0);

//    MIDASsetPosition(playHandle,42);
//    goto jerkele;

//sceneta:

    frames = /*fps = temp =*/ 0; Counter = 0; Counter2 = 0; Counter3=0;
    Scene->CurFrame = 0; //falku = 0;

//ostamopo:
	while(position<flag && Scene->CurFrame<Scene->NumFrames)// && !escpressed)
    {

/*		if(Scene->ClsScrEnabled)
			VbeCls(dblbuf);

		UpdateInfo();

		for(int i=0;i<Scene->Numlights;i++)
		{
			Scene->olights[i].x = Scene->olights[i].pospath[Scene->CurFrame].x;
			Scene->olights[i].y = Scene->olights[i].pospath[Scene->CurFrame].y;
			Scene->olights[i].z = Scene->olights[i].pospath[Scene->CurFrame].z;
		}
		Scene->cameras[Scene->ActiveCamera].px =
		Scene->cameras[Scene->ActiveCamera].pospath[Scene->CurFrame].x;
		Scene->cameras[Scene->ActiveCamera].py =
		Scene->cameras[Scene->ActiveCamera].pospath[Scene->CurFrame].y;
		Scene->cameras[Scene->ActiveCamera].pz =
		Scene->cameras[Scene->ActiveCamera].pospath[Scene->CurFrame].z;
		Scene->cameras[Scene->ActiveCamera].tx =
		Scene->cameras[Scene->ActiveCamera].tgtpath[Scene->CurFrame].x;
		Scene->cameras[Scene->ActiveCamera].ty =
		Scene->cameras[Scene->ActiveCamera].tgtpath[Scene->CurFrame].y;
		Scene->cameras[Scene->ActiveCamera].tz =
		Scene->cameras[Scene->ActiveCamera].tgtpath[Scene->CurFrame].z;

		MakeCamMat(&Scene->cameras[Scene->ActiveCamera]);

		for(i=0;i<Scene->Numobjs;i++)
		{
			if(CurScene<2) {
				int result = ObjectCull(&Scene->objects[i],Scene->cameras[Scene->ActiveCamera].ViewMat,
					Scene->cameras[Scene->ActiveCamera].FarPlane,Scene->cameras[Scene->ActiveCamera].NearPlane);
				if( result == 1) continue;
			}*/
			/*if(CurScene==2)
			{
				if(i==(Scene->Numobjs-1))
				{
					RotateObject(&Scene->objects[i],0,8.0/256.0,0);
					FakeEnvMap = 1;
				}else FakeEnvMap = 0;
			}
			else*/FakeEnvMap = 0;

/*			PolygonCull(&Scene->objects[i], &Scene->cameras[Scene->ActiveCamera]);
			World_To_Camera(&Scene->objects[i], Scene->cameras[Scene->ActiveCamera].ViewMat);
			ClipToPlanes(&Scene->objects[i], Scene->cameras[Scene->ActiveCamera].FarPlane, Scene->cameras[Scene->ActiveCamera].NearPlane);
			if(Scene->RealLights)
				CalcLightAtVert(&Scene->objects[i], Scene, 0);
			Projection(&Scene->objects[i], Scene->RealLights, Scene->ZBuffer, Scene->cameras[Scene->ActiveCamera].NearPlane,FakeEnvMap);
		}*/

		//if(Scene->FlaresEnabled) DisplayFlares(Scene);

      //if(GetKeyState(25))
      //  Scene->ParticlesEnabled = (~Scene->ParticlesEnabled) & 0x0001;
		//if(Scene->ParticlesEnabled) DrawParticles(Scene);

		//if(Scene->ZFogEnabled) CalcFog(Scene);
		clear((char *)Scene->ZBuffer,16000,64000*4);
		VbeFlip(lfb,dblbuf);
	}
	CloseVbe(1);
	if (timer) timeKillEvent(timer);
	cout << "quitting: position" << position << endl;
	cout << "quitting: flag" << flag << endl;
	cout << "quitting: CurFrame" << Scene->CurFrame << endl;
	cout << "quitting: NumFrames" << Scene->NumFrames << endl;
	return 0;
}

      // fps counter
/*      if(Counter2-fpsCounter>=1000)
      {
        fps=frames/(100.0/FPS);
        actFps=actFrames;
        fpsCounter=Counter2;
        actFrames=frames=0;
      }*/

/*		if(CurScene==0)
		{
			if(CurPic!=4)
			{
				if(PicShade1<511)
					PicShade1=Counter3*512/1000;
				else
				{
					if(CurPic<2)
					{
						CurPic+=2;
						Pic1 = Creds[CurPic];
						PicShade1 = 0;
						Counter3=0;
					}
					else CurPic=3;
				}
         
				if(PicShade1>=50 && PicShade2<511)
					PicShade2=Counter3*512/1000;
				else
				{
					if(CurPic<3)
					{
						Pic2 = Creds[CurPic+1];
						PicShade2 = 0;
					}
					else CurPic = 4;
				}
				XFadePic(Pic1,PicShade1);
				XFadePic(Pic2,PicShade2);
				if(CurPic == 4)
				{
					PicShade1=0; Counter3=0;
				}
			} else
			{
				//it is 4th image
				if(PicShade1<511) PicShade1 = Counter3*512/1000;
				XFadePic(EuphLog,PicShade1);
			}
		}*/
      //actFrames++;

      /*if(position>=26 && position<28) {
		  domulju();//goto mulju;
	  } else {*/

      /*if(CurScene==3)
      {
         long greetslogo = 0;
         long greets1    = 0;
         long greets2    = 0;
         long greets1x   = 0;
         long greets2x   = 0;
         long aoffset;

         if( Counter>=(16*30) && Counter<(22*30)) {
           greetslogo = ((Counter-16*30)*255) / (3*30); // 0 -- 512
           if(greetslogo<255) aoffset = (greetslogo>>2)<<12;
           else aoffset = ((255-(greetslogo-256))>>2)<<12;
           unsigned char * MulTbl = (unsigned char *) &multbl[aoffset];
           for(long i=0; i<64000; i++) {
             if(GreLogo->ptr32[i]!=0) {
               unsigned char * cdest  = (unsigned char *) &dblbuf->ptr32[i];
               unsigned char * cpic1  = (unsigned char *) &dblbuf->ptr32[i];
               unsigned char * cpic2  = (unsigned char *) &GreLogo->ptr32[i];
               cdest[0] = MulTbl[ ((cpic2[0] >>2)<<6) + (cpic1[0] >>2) ];
               cdest[1] = MulTbl[ ((cpic2[1] >>2)<<6) + (cpic1[1] >>2) ];
               cdest[2] = MulTbl[ ((cpic2[2] >>2)<<6) + (cpic1[2] >>2) ];
             }
           }
         }
         if( Counter>=(22*30) && Counter<(24*30)) {
           greets1    = (Counter-22*30)*255 / (2*30);          
           aoffset = (greets1>>2)<<12;
           unsigned char * MulTbl = (unsigned char *) &multbl[aoffset];
           for(long i=0; i<64000; i++) {
             if(Greets1->ptr32[i]!=0) {
               unsigned char * cdest  = (unsigned char *) &dblbuf->ptr32[i];
               unsigned char * cpic1  = (unsigned char *) &dblbuf->ptr32[i];
               unsigned char * cpic2  = (unsigned char *) &Greets1->ptr32[i];
               cdest[0] = MulTbl[ ((cpic2[0] >>2)<<6) + (cpic1[0] >>2) ];
               cdest[1] = MulTbl[ ((cpic2[1] >>2)<<6) + (cpic1[1] >>2) ];
               cdest[2] = MulTbl[ ((cpic2[2] >>2)<<6) + (cpic1[2] >>2) ];
             }
           }           
         }
         if( Counter>=(24*30) && Counter<(26*30)) {
           greets1 = 255;//
           aoffset = (greets1>>2)<<12;
           unsigned char * MulTbl = (unsigned char *) &multbl[aoffset];
           for(long i=0; i<64000; i++) {
             if(Greets1->ptr32[i]!=0) {
               unsigned char * cdest  = (unsigned char *) &dblbuf->ptr32[i];
               unsigned char * cpic1  = (unsigned char *) &dblbuf->ptr32[i];
               unsigned char * cpic2  = (unsigned char *) &Greets1->ptr32[i];
               cdest[0] = MulTbl[ ((cpic2[0] >>2)<<6) + (cpic1[0] >>2) ];
               cdest[1] = MulTbl[ ((cpic2[1] >>2)<<6) + (cpic1[1] >>2) ];
               cdest[2] = MulTbl[ ((cpic2[2] >>2)<<6) + (cpic1[2] >>2) ];
             }
           }           
         }
         if( Counter>=(26*30) && Counter<(29*30)) {
           greets1 = 255-((Counter-26*30)*255 / (3*30));
           aoffset = (greets1>>2)<<12;
           unsigned char * MulTbl = (unsigned char *) &multbl[aoffset];
           for(long i=0; i<64000; i++) {
             if(Greets1->ptr32[i]!=0) {
               unsigned char * cdest  = (unsigned char *) &dblbuf->ptr32[i];
               unsigned char * cpic1  = (unsigned char *) &dblbuf->ptr32[i];
               unsigned char * cpic2  = (unsigned char *) &Greets1->ptr32[i];
               cdest[0] = MulTbl[ ((cpic2[0] >>2)<<6) + (cpic1[0] >>2) ];
               cdest[1] = MulTbl[ ((cpic2[1] >>2)<<6) + (cpic1[1] >>2) ];
               cdest[2] = MulTbl[ ((cpic2[2] >>2)<<6) + (cpic1[2] >>2) ];
             }
           }           
         }
         if( Counter>=(28*30) && Counter<(30*30)) {
           greets2 = (Counter-28*30)*255 / (2*30);          
           aoffset = (greets2>>2)<<12;
           unsigned char * MulTbl = (unsigned char *) &multbl[aoffset];
           for(long i=0; i<64000; i++) {
             if(Greets2->ptr32[i]!=0) {
               unsigned char * cdest  = (unsigned char *) &dblbuf->ptr32[i];
               unsigned char * cpic1  = (unsigned char *) &dblbuf->ptr32[i];
               unsigned char * cpic2  = (unsigned char *) &Greets2->ptr32[i];
               cdest[0] = MulTbl[ ((cpic2[0] >>2)<<6) + (cpic1[0] >>2) ];
               cdest[1] = MulTbl[ ((cpic2[1] >>2)<<6) + (cpic1[1] >>2) ];
               cdest[2] = MulTbl[ ((cpic2[2] >>2)<<6) + (cpic1[2] >>2) ];
             }
           }
         }
         if( Counter>=(30*30) && Counter<(32*30)) {
           greets2 = 255;//(Counter-28*30)*255 / (2*30);          
           aoffset = (greets2>>2)<<12;
           unsigned char * MulTbl = (unsigned char *) &multbl[aoffset];
           for(long i=0; i<64000; i++) {
             if(Greets2->ptr32[i]!=0) {
               unsigned char * cdest  = (unsigned char *) &dblbuf->ptr32[i];
               unsigned char * cpic1  = (unsigned char *) &dblbuf->ptr32[i];
               unsigned char * cpic2  = (unsigned char *) &Greets2->ptr32[i];
               cdest[0] = MulTbl[ ((cpic2[0] >>2)<<6) + (cpic1[0] >>2) ];
               cdest[1] = MulTbl[ ((cpic2[1] >>2)<<6) + (cpic1[1] >>2) ];
               cdest[2] = MulTbl[ ((cpic2[2] >>2)<<6) + (cpic1[2] >>2) ];
             }
           }
         }
         if( Counter>=(32*30) && Counter<(36*30)) {
           greets2 = 255-((Counter-32*30)*255 / (4*30));
           aoffset = (greets2>>2)<<12;
           unsigned char * MulTbl = (unsigned char *) &multbl[aoffset];
           for(long i=0; i<64000; i++) {
             if(Greets2->ptr32[i]!=0) {
               unsigned char * cdest  = (unsigned char *) &dblbuf->ptr32[i];
               unsigned char * cpic1  = (unsigned char *) &dblbuf->ptr32[i];
               unsigned char * cpic2  = (unsigned char *) &Greets2->ptr32[i];
               cdest[0] = MulTbl[ ((cpic2[0] >>2)<<6) + (cpic1[0] >>2) ];
               cdest[1] = MulTbl[ ((cpic2[1] >>2)<<6) + (cpic1[1] >>2) ];
               cdest[2] = MulTbl[ ((cpic2[2] >>2)<<6) + (cpic1[2] >>2) ];
             }
           }
         }

      };

      VbeFlip(lfb,dblbuf);*/

      //double floppu = Counter;
      //Scene->CurFrame = Scene->CurFrame + double((floppu-falku));
      //falku = floppu;

    //}
    //if(escpressed) exit(0);//goto loppu;

//    UpdateInfo();

    //if(position<42)
    //{
/*      rotzoom->scaleangdiff = 1.0;
  mulju:
      //Muljutusta
      while(position<42 && !escpressed)
      {
        escpressed = GetKeyState(1);
        long FrameNum = (Counter)-1800;
//        UpdateInfo();
        
        if(FrameNum<0) FrameNum=0;
          //goto ostamopo;
        UpdateSpline(Spln ,FrameNum);
        UpdateSpline(Spln2,FrameNum);
        UpdateSpline(Spln3,FrameNum);
        UpdateSpline(Spln4,FrameNum);
        UpdateSpline(Spln5,FrameNum);
        UpdateSpline(Spln6,FrameNum);
        PICTURE * morphed  = XFadeTextures(pic,     texture,  Spln2->x , &txtr);
        PICTURE * morphed2 = XFadeTextures(morphed, texture2, Spln3->x , &txtr2);
        PICTURE * morphed3 = XFadeTextures(morphed2,texture3, Spln3->x-256, &txtr2);
        Tunnel.origin[0] = Spln4->x-180;
        Tunnel.origin[1] = Spln4->y-180;
        Tunnel.origin[2] = Spln4->z-768;
        Tunnel.XrotAng   = Spln5->x;
        Tunnel.YrotAng   = Spln5->y;
        Tunnel.ZrotAng   = Spln5->z;

        FdTunnel(&Tunnel);
        rotzoom->centerX = 0;
        rotzoom->centerY = 0;
        rotzoom->scalefactor    = Spln->x/256.0;
        rotzoom->scaleangdiff   = Spln6->x/256.0;
        rotzoom->rottwistvoima  = Spln2->y;
        rotzoom->zoomtwistvoima = Spln2->z;
        rotzoom->rotangle  = Spln->y;
        rotzoom->zoomangle = Spln->z;  
        RotateZoom2d(rotzoom,1);
        DrawGrid(Grid, Grid2, Spln3->y, morphed3, dblbuf2);

        if( FrameNum>=(8*30) && FrameNum<(16*30) ) {
          char a = (FrameNum-(8*30))*255/(8*30); // 0 -- 255
//          char ima = 255-a;
          long aoffs = (a>>2)<<12;
          for(int i=0;i<64000;i++) {
            if(Dnaama->ptr32[i]!=0) {
              char * cpic1  = (char *) &Dnaama->ptr32[i];
              char * cpic2  = (char *) &dblbuf2->ptr32[i];
              char b=multbl[aoffs+((cpic1[0]>>2)<<6)+(cpic2[0]>>2)];
              char g=multbl[aoffs+((cpic1[1]>>2)<<6)+(cpic2[1]>>2)];
              char r=multbl[aoffs+((cpic1[2]>>2)<<6)+(cpic2[2]>>2)];

              dblbuf2->ptr32[i] = (r<<16)+(g<<8)+b;
            }
          }
        }
        if(FrameNum>=16*30) 
          for(int i=0;i<64000;i++) {if(Dnaama->ptr32[i]!=0)
              dblbuf2->ptr32[i] = Dnaama->ptr32[i];}

        VbeFlip(lfb, dblbuf2);

        if(position>=26 && position<28) goto ostamopo;

      }
      if(escpressed) exit(0);//goto loppu;*/
    //}
//jerkele:
//    UpdateInfo();
 /*   if(position<=42)
    {
       clear((char *)Scene->ZBuffer,16000,64000*4);
       VbeCls(lfb);
       VbeCls(dblbuf);
      //MeriScene
      CurScene++;
      Scene->CurFrame = 1;

      Scene = Scenes[CurScene];

      //Scene->NumFrames=1800;
      flag = 62; //58

     frames = fps = temp = 0; Counter = 0; Counter2 = 0; Counter3=0;
     Scene->CurFrame = 0; falku = 0;
     //continue;//goto sceneta;
    }

    else if(position<=62)   //62
    {

       VbeCls(lfb);
       VbeCls(dblbuf);

       flip32bit(dblbuf->ptr32, EuphSel->ptr32, 64000);
       VbeFlip(lfb,dblbuf);

       //Euphoriaselitys
       while(position<66 && !escpressed)
       {
         //escpressed = GetKeyState(VK_ESCAPE);
         UpdateInfo();  
       }
       if(escpressed) exit(0);//goto loppu;

    }
//    UpdateInfo();

    else if(position<=66)   //62
    {
       VbeCls(lfb);
       VbeCls(dblbuf);

       //Mausoleum
       CurScene++;
       Scene = Scenes[CurScene];

       flag = 74; //70
       frames = fps = temp = 0; Counter = 0; Counter2 = 0; Counter3=0;
       Scene->CurFrame = 0; falku = 0;
       //continue;//goto sceneta;
    }                           

//    UpdateInfo();
    else if(position<=74) //74
    {
       VbeCls(lfb);
       VbeCls(dblbuf);

       //Saifaisiin
       CurScene++;
       //CurScene=3;
       Scene = Scenes[CurScene];

       flag = 92;   //85
       frames = fps = temp = 0; Counter = 0; Counter2 = 0; Counter3=0;
       Scene->CurFrame = 0; falku = 0;
       //continue;//goto sceneta;
    }
 //     UpdateInfo();
    else if(position<=92) // 85
    {
      // MIDASsetPosition(playHandle,87);

       VbeCls(lfb);
       VbeCls(dblbuf);

       for(int i=0;i<64000;i++) dblbuf->ptr32[i] = EndPic->ptr32[i];
       VbeFlip(lfb,dblbuf);

       //Loppukuva
       while(position<96 && !escpressed)
       {
          UpdateInfo();
          //escpressed = GetKeyState(VK_ESCAPE);
       }
       if(escpressed) exit(0);//goto loppu;
    }*/
//		UpdateInfo();
	//} //else do mulju
//}}
//loppu:


//  Remove_KeybDrv();
/*  CloseVbe(1);
 if (timer) timeKillEvent(timer);

  //cout << (dec) << Scene->CurFrame/(Counter2/1000) << endl;
  return 0;
}
}*/

void SetupScene( World *Scene, short RealLights, short ZFogEnabled, short FlaresEnabled, float FarPlane, float NearPlane, short ClsScrEnabled, short ParticlesEnabled)
{
  Scene->ActiveCamera = 0;    //default, multiple cameras not implemented yet
  Scene->CurFrame = 0;

  Scene->RealLights = RealLights;
  Scene->ZFogEnabled = ZFogEnabled;
  Scene->FlaresEnabled = FlaresEnabled;
  Scene->ClsScrEnabled = ClsScrEnabled;
  Scene->ParticlesEnabled = ParticlesEnabled;
  Scene->cameras[Scene->ActiveCamera].FarPlane = FarPlane;
  Scene->cameras[Scene->ActiveCamera].NearPlane = NearPlane;


  Scene->ZBuffer = new unsigned long[64000];
/*  CalcCardinalSpline();
  ComputeObjRadius(Scene);
  CalcVNormals(Scene);
  if(ZFogEnabled)
  {
    Scene->fogtable = new bits_24[256*256];
    CalcFogTable(Scene->fogtable);
  }
  else Scene->fogtable = NULL;
*/
   for(int dw=0;dw<Scene->Numobjs;dw++)
      for(int i=0;i<Scene->objects[dw].nverts;i++) 
      {
        Scene->objects[dw].ConstLightAtVert[i].r =
        Scene->objects[dw].ConstLightAtVert[i].g =
        Scene->objects[dw].ConstLightAtVert[i].b = 
        Scene->objects[dw].LightAtVert[i].r =
        Scene->objects[dw].LightAtVert[i].g =
        Scene->objects[dw].LightAtVert[i].b =
        Scene->objects[dw].LightAtVert[i].Calculated = 
        Scene->objects[dw].ConstLightAtVert[i].Calculated = 0;

      }

  /*for(int weit=0;weit<Scene->Numlights;weit++)
  {
    if(Scene->olights[weit].NumLightPosFrame<=1)
     for(int i=0;i<Scene->Numobjs;i++)
      CalcLightAtVert(&Scene->objects[i],Scene,1);
  } 

  for(d=0;d<Scene->Numlights;d++)
  {
     Scene->olights[d].Flare = new Sprite;
     Scene->olights[d].Flare->Buffer = LoadPicture("flare4.tga");
     Scene->olights[d].Flare->XLen = Scene->olights[d].Flare->Buffer->Width;
     Scene->olights[d].Flare->YLen = Scene->olights[d].Flare->Buffer->Height;
     ChangePicture(Scene->olights[d].Flare->Buffer,Scene->olights[d].Flare->Buffer->Width,Scene->olights[d].Flare->Buffer->Height,32);

     Scene->olights[d].pospath = new Vertex[Scene->NumFrames];
     for(int i=0;i<Scene->NumFrames;i++)
     {
        AnimateLights(&Scene->olights[d],i);
        Scene->olights[d].pospath[i].x = Scene->olights[d].x;
        Scene->olights[d].pospath[i].y = Scene->olights[d].y;
        Scene->olights[d].pospath[i].z = Scene->olights[d].z;
     }
     
  }

  for(d=0;d<Scene->Numcams;d++)
  {
     Scene->cameras[d].pospath = new Vertex[Scene->NumFrames];
     Scene->cameras[d].tgtpath = new Vertex[Scene->NumFrames];

     for(int i=0;i<Scene->NumFrames;i++)
     {
        AnimateCamera(&Scene->cameras[d],i);
        Scene->cameras[d].pospath[i].x = Scene->cameras[d].px;
        Scene->cameras[d].pospath[i].y = Scene->cameras[d].py;
        Scene->cameras[d].pospath[i].z = Scene->cameras[d].pz;

        Scene->cameras[d].tgtpath[i].x = Scene->cameras[d].tx;
        Scene->cameras[d].tgtpath[i].y = Scene->cameras[d].ty;
        Scene->cameras[d].tgtpath[i].z = Scene->cameras[d].tz;

     }
  }*/

  if(Scene->ParticlesEnabled)
   SetupParticles(Scene,200,1,Scene->olights[0].x,Scene->olights[0].z,Scene->olights[0].y);
  
}

void CalcFogTable(bits_24 *fogtable)
{
  for(long shade=0; shade<256; shade++) {
   for(long color=0; color<256; color++) {
    fogtable[shade*256+color].r = color + ( ((0- color)*shade) /256);
    fogtable[shade*256+color].g = color + ( ((40- color)*shade) /256);
    fogtable[shade*256+color].b = color + ( ((24- color)*shade) /256);
   }
  } 
}

void CalcFog(World *Scene)
{
    long r,g,b,z;
//    bits_24 *fogptr;
    unsigned long *ZBufptr = Scene->ZBuffer;

    for(int i=0;i<64000;i++)
    {
      unsigned char * texel = (unsigned char *) &dblbuf->ptr32[i];
      z = (*ZBufptr++) >> 16;
      if(z<256) {
       r = Scene->fogtable[(z<<8)+texel[2]].r;
       g = Scene->fogtable[(z<<8)+texel[1]].g;
       b = Scene->fogtable[(z<<8)+texel[0]].b;
       long output = (r<<16) + (g << 8) + (b);
       dblbuf->ptr32[i] = output;
      } else {
       dblbuf->ptr32[i] = 0x002717;
      }
    }
}

void DisplayFlares(World *Scene)
{
    for(int i=0;i<Scene->Numlights;i++)
    {
     Scene->olights[i].Flare->Xp = Scene->olights[i].x * Scene->cameras[Scene->ActiveCamera].ViewMat[0][0] +
                Scene->olights[i].z * Scene->cameras[Scene->ActiveCamera].ViewMat[1][0] +
                Scene->olights[i].y * Scene->cameras[Scene->ActiveCamera].ViewMat[2][0] + Scene->cameras[Scene->ActiveCamera].ViewMat[3][0];
     Scene->olights[i].Flare->Yp = Scene->olights[i].x * Scene->cameras[Scene->ActiveCamera].ViewMat[0][1] +
                Scene->olights[i].z * Scene->cameras[Scene->ActiveCamera].ViewMat[1][1] +
                Scene->olights[i].y * Scene->cameras[Scene->ActiveCamera].ViewMat[2][1] + Scene->cameras[Scene->ActiveCamera].ViewMat[3][1];
     Scene->olights[i].Flare->Zp = Scene->olights[i].x * Scene->cameras[Scene->ActiveCamera].ViewMat[0][2] +
                Scene->olights[i].z * Scene->cameras[Scene->ActiveCamera].ViewMat[1][2] +
                Scene->olights[i].y * Scene->cameras[Scene->ActiveCamera].ViewMat[2][2] + Scene->cameras[Scene->ActiveCamera].ViewMat[3][2];
     Scene->olights[i].DrawFlare(dblbuf,&Scene->cameras[Scene->ActiveCamera],Scene->ZBuffer);
    }
}

void SetupParticles(World *Scene,int NumF,int NumP,float XPos,float YPos,float ZPos)
{
  Scene->psources = NULL;
  /*Scene->NumF = NumF;
  if(NumF>0)
  {
    Scene->psources = new psource[NumF];

    for(int i=0;  i<NumF/3; i++) Scene->psources[i].setup(XPos+sin(double(i)/6.4)*5.0,YPos+cos(double(i)/6.4)*5.0,ZPos                       ,pTEST,NumP);
    for(i=NumF/3; i<NumF/2; i++) Scene->psources[i].setup(XPos+sin(double(i)/6.4)*5.0,YPos                       ,ZPos+cos(double(i)/6.4)*5.0,pTEST,NumP);
    for(i=NumF/2; i<NumF/1; i++) Scene->psources[i].setup(XPos                       ,YPos+sin(double(i)/6.4)*5.0,ZPos+cos(double(i)/6.4)*5.0,pTEST,NumP);
  }*/

}

void DrawParticles(World *Scene)
{
/*    for(int a=0; a<Scene->NumF; a++)
    {
      Scene->psources[a].update();

      for(int i=0; i<Scene->psources[a].numP; i++)
      {
        Flare.Xp =  Scene->psources[a].particles[i].x * Scene->cameras[Scene->ActiveCamera].ViewMat[0][0] +
                    Scene->psources[a].particles[i].y * Scene->cameras[Scene->ActiveCamera].ViewMat[1][0] +
                    Scene->psources[a].particles[i].z * Scene->cameras[Scene->ActiveCamera].ViewMat[2][0] + Scene->cameras[Scene->ActiveCamera].ViewMat[3][0];
        Flare.Yp =  Scene->psources[a].particles[i].x * Scene->cameras[Scene->ActiveCamera].ViewMat[0][1] +
                    Scene->psources[a].particles[i].y * Scene->cameras[Scene->ActiveCamera].ViewMat[1][1] +
                    Scene->psources[a].particles[i].z * Scene->cameras[Scene->ActiveCamera].ViewMat[2][1] + Scene->cameras[Scene->ActiveCamera].ViewMat[3][1];
        Flare.Zp =  Scene->psources[a].particles[i].x * Scene->cameras[Scene->ActiveCamera].ViewMat[0][2] +
                    Scene->psources[a].particles[i].y * Scene->cameras[Scene->ActiveCamera].ViewMat[1][2] +
                    Scene->psources[a].particles[i].z * Scene->cameras[Scene->ActiveCamera].ViewMat[2][2] + Scene->cameras[Scene->ActiveCamera].ViewMat[3][2];
        if(Flare.Zp<Scene->cameras[Scene->ActiveCamera].NearPlane ||
           Flare.Zp>Scene->cameras[Scene->ActiveCamera].FarPlane) continue;
        int t=round( ((long double)Counter2-Scene->psources[a].particles[i].borntime)/(Scene->psources[a].particles[i].lifetime-Scene->psources[a].particles[i].borntime)*255);
        if(t>255) t=255;
        DrawLight(&Flare,dblbuf,Scene->ZBuffer,&Scene->cameras[Scene->ActiveCamera],t);
      }
    }*/
}

/*void MIDASerror(void)
{
    CloseVbe(1);

    printf("MIDAS error: %s\n", MIDASgetErrorMessage(MIDASgetLastError()));
#ifndef NOMUSIC
//    MIDASclose(); 
#endif
    exit(EXIT_FAILURE);
}*/

int XFadePic(PICTURE *Pic,long Shade)
{
    if(Shade>=511) return 1;

    if(Shade>255) Shade = 511 - Shade;

    if(Pic->ptr8!=NULL)
    {
     for(int i=0;i<64000;i++)
     {
      if(Pic->ptr8[i]!=0)
      {

         unsigned char col = Pic->ptr8[i];
         unsigned char *dbltex = (unsigned char *) &dblbuf->ptr32[i];
         unsigned long index = (col << 8) + Shade;
         unsigned long r = Pic->ShadeTable->Table[index].r;
         unsigned long g = Pic->ShadeTable->Table[index].g;
         unsigned long b = Pic->ShadeTable->Table[index].b;
         r+=dbltex[2];
         g+=dbltex[1];
         b+=dbltex[0];
         if(r>255) r = 255;
         if(g>255) g = 255;
         if(b>255) b = 255;

         dblbuf->ptr32[i] = (r << 16) + (g << 8) + b;
      } 
     }
    }
/*    else if(Pic->ptr32!=NULL)
    {
     for(int i=0;i<64000;i++)
     {
      if(Pic->ptr32[i]!=0)
      {

         char *pictex = (char *) &Pic->ptr32[i];
         char *dbltex = (char *) &dblbuf->ptr32[i];
         long r = (pictex[2]*Shade)>>8
         long g = (pictex[1]*Shade)>>8
         long b = (pictex[0]*Shade)>>8

         r+=dbltex[2];
         g+=dbltex[1];
         b+=dbltex[0];
         if(r>255) r = 255;
         if(g>255) g = 255;
         if(b>255) b = 255;

         dblbuf->ptr32[i] = (r << 16) + (g << 8) + b;
      } 
     }

    }    */
    return 0;
};

void UpdateInfo()
{
	BASS_Update();
	QWORD res = BASS_ChannelGetPosition(chan); // LOWORD=order HIWORD=row

	position = res & 0x0000ffff;
	row = (res>>16) & 0x0000ffff;

	MSG msg;
	if( PeekMessage( &msg, vesahwnd, 0U, 0U, PM_REMOVE ) )
	{
		TranslateMessage( &msg );
		DispatchMessage( &msg );
	}
}

/*void MIDAS_CALL UpdateInfo(void)
{
    
    
    static MIDASplayStatus status;

 
    if ( !MIDASgetPlayStatus(playHandle, &status) )
        MIDASerror();

  
    position = status.position;
    pattern = status.pattern;
    row = status.row;
    syncInfo = status.syncInfo;
}*/

int DoBump(void)
{
	long loop1,x,y,i;  
	srand(0);
	unsigned char * Clip0_256_ = &Clip0_256[256];
	unsigned char * phongmap   = new unsigned char[65536];
	long          * bumpmap    = new long[320*200];
	unsigned long * lightmap   = new unsigned long[384*264];

	LIGHT * lights = new LIGHT[256];

	Demologo = LoadPCX("demologo.pcx",320,200,8);  
	PICTURE * tmp = LoadPCX("logtaust.pcx",320,200,8);
	for( loop1=0; loop1<64000; loop1++)
		bumpmap[loop1] = tmp->ptr8[loop1];
 
	PICTURE * kuva = LoadTGA("flare2.tga");

	lights[0].ptr8 = new unsigned char[32*32];
	for(y=0; y<32; y++)
	{
		for(x=0; x<32; x++)
		{
			int offset = y*32+x;
			lights[0].ptr8[offset] = (kuva->ptr24[offset].r+kuva->ptr24[offset].g+kuva->ptr24[offset].b)/3.0f;
		}
	}
	for(y=1; y<256; y++) lights[y].ptr8 = lights[0].ptr8;  
	for(y=0; y<256; y++)
	{
		for(long x=0; x<256; x++)
		{
			pmapshadet[y+x*256] = x*y/256;
		}  
		lights[y].RGB   = (unsigned long *) &lights[y].b;
		lights[y].Width = lights[y].Height = 32;  
		lights[y].r = rand()%256;
		lights[y].g = rand()%256;
		lights[y].b = rand()%256;
		lights[y].pos = CreateSpline(35,30, 320, 200, 256, 0, 0); 
		lights[y].startframe = y*45;
	}  
	BUMPSTRUCT jee;
 
	jee.pic      = Demologo;
	jee.bumpmap  = bumpmap;
	jee.dest     = dblbuf;
	jee.lightmap = lightmap;

// if ( !MIDASsetTimerCallbacks(1000000, FALSE, &prevr, NULL, NULL) )
//       MIDASerror();
	//timeBeginPeriod(10);
	timer = timeSetEvent(10, 10, (LPTIMECALLBACK)&prevr, 0, TIME_PERIODIC);
	//wintimer = timeSetEvent(250.0f, 100.0f, (LPTIMECALLBACK)&winmsgloop, 0, TIME_PERIODIC);

	if(timer == 0 /*|| wintimer == 0*/)
	{
		exit(0);
	}

 /* Start playing the module: */
// if ( (playHandle = MIDASplayModule(module, TRUE)) == 0 )
//    MIDASerror();
	BASS_MusicPlay(chan);
	UpdateInfo();
 //while(position<10) UpdateInfo(); 
 //exit(0);

	escpressed = 0;
//	long endfade=0;
	return 0;
	while(position<10 && !escpressed )
	{
		//escpressed = GetKeyState(VK_ESCAPE);
		long FrameNum = Counter;
		UpdateInfo();
		cls32bit(lightmap, 64000);
		for(i=0; i<35; i++)
		{
			UpdateSpline(lights[i].pos, FrameNum);
		}
		long red, green, blue;
		for(i=0; i<35; i++)
		{
			if(FrameNum < lights[i].startframe ) continue;
			if(FrameNum < (lights[i].startframe+4*30) )
			{
				long a = (FrameNum-lights[i].startframe)*255/(4*30);
				long aoffs = (a>>2)<<12;
				blue = multbl[aoffs+((lights[i].b>>2)<<6)];
				green= multbl[aoffs+((lights[i].g>>2)<<6)];
				red  = multbl[aoffs+((lights[i].r>>2)<<6)];
			} else
			{
				blue = lights[i].b;
				green= lights[i].g;
				red  = lights[i].r;
			}
			long Ustart, Vstart;
			long upperx,uppery,lowerx,lowery,Xsize,Ysize;
			long Scale = lights[i].pos->z; // z = 0 -- 255
			if(Scale > 255) Scale = 255;
			if(Scale < 0  ) Scale = 0  ;
			Ysize  = Xsize   = 32+(Scale/4); // Scale = 32 -- 96
			upperx = lights[i].pos->x-(Xsize>>1);
			uppery = lights[i].pos->y-(Ysize>>1);
			lowerx = upperx + Xsize;
			lowery = uppery + Ysize;
  
			if(upperx<319 && uppery<199 && lowerx>0 && lowery>0 )
			{
				long deltax = (32*256) / Xsize;
				long deltay = (32*256) / Ysize;
				Ustart=Vstart=0;
				if(upperx<0) {
					long Xero = 0-upperx;
					Ustart = deltax*Xero;
					upperx = 0;
				}
				if(uppery<0) {
					long Yero = 0-uppery;
					Vstart = deltay*Yero;
					uppery = 0;
				}
				if(lowerx>319) lowerx = 319;
				if(lowery>199) lowery = 199;

				long YOffs = uppery*320;
				long Vpos=Vstart;
				for(y=uppery; y<lowery; y++)
				{
					long LightVOffs=(Vpos>>8)*32;
					long Upos = Ustart;
					for(x=upperx; x<lowerx; x++)
					{
						unsigned char * oldtex = (unsigned char*)&lightmap[YOffs+x];
						unsigned char * dest   = (unsigned char*)&lightmap[YOffs+x];
						unsigned char * texel  = &lights[0].ptr8[LightVOffs+(Upos>>8)];

						dest[2] = Clip0_256_[ (pmapshadet[*texel+(red  <<8)])+oldtex[2] ];
						dest[1] = Clip0_256_[ (pmapshadet[*texel+(green<<8)])+oldtex[1] ];
						dest[0] = Clip0_256_[ (pmapshadet[*texel+(blue <<8)])+oldtex[0] ];

						Upos+=deltax;
						dblbuf->ptr32[YOffs+x] = lightmap[YOffs+x];
					}
					YOffs+=320;
					Vpos+=deltay;
				}
			}
		}
		vesabump(&jee);

		if(FrameNum>31*30)
		{
			long a = (((FrameNum-31*30))*256) / (2*30);
			if(a>=255)
			{
				flip32bit(dblbuf2->ptr32,Demolog->ptr32,64000);
			} else if(a<=0)
			{
				flip32bit(dblbuf2->ptr32,dblbuf->ptr32,64000);
			} else
			{
				long aoffset = (a>>2)<<12;
				unsigned char * MulTbl = (unsigned char *) &multbl[aoffset];
				unsigned char * cpic1  = (unsigned char *) dblbuf->ptr32;
				unsigned char * cpic2  = (unsigned char *) Demolog->ptr32;
				unsigned char * cdest  = (unsigned char *) dblbuf2->ptr32;
				for(long i=0; i<64000; i++)
				{
					cdest[0] = MulTbl[ ((cpic2[0] >>2)<<6) + (cpic1[0] >>2) ];
					cdest[1] = MulTbl[ ((cpic2[1] >>2)<<6) + (cpic1[1] >>2) ];
					cdest[2] = MulTbl[ ((cpic2[2] >>2)<<6) + (cpic1[2] >>2) ];
					cdest+=4;
					cpic1+=4;
					cpic2+=4;
				}
			}
			VbeFlip(lfb,dblbuf2);
		}
		else VbeFlip(lfb,dblbuf);

		VbeCls(dblbuf);
		UpdateInfo();
	}

	VbeCls(lfb);
	VbeCls(dblbuf);
	if(escpressed) return 1;
	//timeEndPeriod(10);
	return 0;
}

long vesabump( BUMPSTRUCT * param1 ) {
 long u,v;
 long x_ero,y_ero;
 long x, y;
 long ly,lx;
 
 long * bumpptr = param1->bumpmap+320;
 unsigned long * dest = param1->dest->ptr32+320;
 unsigned char * pic = param1->pic->ptr8+320;
 unsigned char * jee = (unsigned char *)pic;

 for( x=0; x<320; x++) {
  param1->dest->ptr32[x        ] = 0;
  param1->dest->ptr32[199*320+x] = 0;
 }
 
// char Bvalo,Gvalo,Rvalo;
 long r,g,b;
   
 ly  = 0;
// long offset=320;
 for( y=1; y<199; y++) {
  lx  = 0;
  for( x=0; x<320; x++) {
   x_ero = ( *(bumpptr  -1) - *(bumpptr  +1) )>>1;         // ranges: -256 - +256 
   y_ero = ( *(bumpptr-320) - *(bumpptr+320) )>>1;         // ranges: -256 - +256
   
   u  = x_ero +lx;
   v  = y_ero +ly;
   
   if( u>0&&u<320 && v>0&&v<200 ) {
    unsigned char * RGB = (unsigned char*)&param1->lightmap[(v<<8)+(v<<6)+u];
    b = param1->pic->ShadeTable->Table[(*jee<<8)+RGB[0]].b;
    g = param1->pic->ShadeTable->Table[(*jee<<8)+RGB[1]].g;
    r = param1->pic->ShadeTable->Table[(*jee<<8)+RGB[2]].r;
    *dest++ = b +(g<<8) +(r<<16);
   } else *dest++ = 0;
   jee++;  
   bumpptr++;
   lx++;
  }
  ly++;
 } 
 return 0;
}
