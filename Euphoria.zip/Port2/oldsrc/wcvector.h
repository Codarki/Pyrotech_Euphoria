#ifndef _PT_WCVECTOR_H
#define _PT_WCVECTOR_H

#include <vector>
//#define WCValVector std::vector
//#define length() size()
//typedef std::vector WCValVector ;

#endif