extern "C" {
 
  long		GetDPMImem();
  long		AllocDPMImem();
//  #pragma aux GetDPMImem "*_";
 
} 
