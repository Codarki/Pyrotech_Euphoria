#include <stdio.h>
#include <conio.h>
#include <math.h>
#include "misc.h"

struct Point
{
  float x,y;
};

float Car0(float u);
float Car1(float u);
float Car2(float u);
float Car3(float u);

float t = 0;
float s = (1 - t / 2);

int main(void)
{
  Point P[4];

  P[0].x = 160-30;
  P[0].y = 100;
  P[1].x = 160;
  P[1].y = 100-30;
  P[2].x = 160+30;
  P[2].y = 100;
  P[3].x = 160;
  P[3].y = 100+30;
  int FirstCp = 0;
  int LastCp = 3;


  float u=0;
  setmode(0x13);
  int x,y;
  for(int i=0;i<3;i++)
  {
   int k1 = i - 1;        
   int k2 = i;           
   int k3 = i + 1;        
   int k4 = i + 2;        
   if(k1<0) k1 = 3;
   if(k4>3) k4 = 0;
   u=0;
   while(u<1)
   {
     x = P[k1].x * Car0(u) + P[k2].x * Car1(u) + P[k3].x * Car2(u) + P[k4].x * Car3(u);
     y = P[k1].y * Car0(u) + P[k2].y * Car1(u) + P[k3].y * Car2(u) + P[k4].y * Car3(u);
     putpixel(x,y,15,Vga);
     u+=0.002;
   }
  }
  getch();
  setmode(0x03);
  


  return 0;
}

float Car0(float u)
{
  return (float(-s*u*u*u + 2*s*u*u - s*u));
}

float Car1(float u)
{
  return(float((2-s)*u*u*u + (s-3)*u*u + 1));
}

float Car2(float u)
{
  return(float((s-2)*u*u*u + (3-2*s)*u*u + s*u));
}

float Car3(float u)
{
  return(float(s*u*u*u - s*u*u));
}
