class particle
{
  public:

  double x,y,z;
  double vx,vy,vz;
  double ax,ay,az;
  double m;
  long double borntime;
  long double lifetime;

  particle() { shoot(0,0,1); }
  ~particle() {}
  void shoot(double sx,double sy,double sz);
  void update(void);
};
