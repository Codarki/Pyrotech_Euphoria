#include <stdio.h>
#include <conio.h>
#include <math.h>
#include <dos.h>
#include <iostream.h>
#include "3dmisc.h"
#include "c:\code\wc\ftn\vesa.h"
#include "c:\code\wc\ftn\3dsrdr.h"
#include "c:\code\wc\ftn\vbepoly.h"

long st[65536];
long ct[65536];
 
class SCENEc{
 public:
 
 long noobjects;
 long nocameras;
 long nolights;
 
 //OBJECTc * objects;
 
 SCENEc();
 ~SCENEc();
};

SCENEc::SCENEc() {
 noobjects=nocameras=nolights=0;
 //objects=NULL;
}
SCENEc::~SCENEc() { 
 //delete objects;
}

long main() {  
 long loop1, loop2;
 for( loop1=0; loop1<65536; loop1++) {
  st[loop1]=sin(3.1415/32768*loop1)*256.0;
  ct[loop1]=cos(3.1415/32768*loop1)*256.0;
 }
 
 #include "setvesa.h"
   
 long i,i2,i3,ii,iii,o;
 
 while(!kbhit()){ 
      
 }
 delete dblbuf->ptr4;
 delete dblbuf;
   
 getch();
 CloseVbe(1); 

 return 0;
}