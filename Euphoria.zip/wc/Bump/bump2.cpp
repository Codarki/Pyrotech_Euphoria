#include <iostream.h>
#include <conio.h>
#include <math.h>
//#include "misc.h"
#include "c:\code\wc\ftn\vesa.h"
#include "c:\code\wc\ftn\pcx.h"
#include "bump.h"

char   * pmapshadet  = new char[256*256];
_24Bit * picshadet   = new _24Bit[256*256];
char   * pal         = new char[768];
 
long vesabump( BUMPSTRUCT * param1 );
  
long vesabump( BUMPSTRUCT * param1 ) { 
/* static long u,v,u2,v2,u3,v3;
 static long r_valo,g_valo,b_valo;
 static long x_ero,y_ero;
 static long x, y;
 static long ly, ly2, ly3;
 static long lx, lx2, lx3;*/
 long u,v,u2,v2,u3,v3;
 long r_valo,g_valo,b_valo;
 long x_ero,y_ero;
 long x, y;
 long ly, ly2, ly3;
 long lx, lx2, lx3;
// long texel;
 
 long valot_256[15];
 for( y=1; y<15; y++)
   valot_256[y] = param1->lights[y]<<8;
 
 long * bumpptr = param1->bumpmap+320;
 short * dest = (short *)(param1->dest);
 char * pic = param1->pic+320;
 char * jee = (char *)pic;
  
 ly  = -param1->lights[1]+128 ;    // light: 0-319 ranges: -191 - +128
 ly2 = -param1->lights[6]+128 ;    // light: 0-255 ranges: -127 - +128
 ly3 = -param1->lights[11]+128 ;
 long offset=321;
 for( y=1; y<199; y++) {
  lx  = -param1->lights[0]+128;    // light: 0-199 ranges: -71 - +128
  lx2 = -param1->lights[5]+128;
  lx3 = -param1->lights[10]+128;
  for( x=1; x<319; x++) {
   x_ero = ( *(bumpptr  -1) - *(bumpptr  +1) );         // ranges: -256 - +256
   y_ero = ( *(bumpptr-320) - *(bumpptr+320) );         // ranges: -256 - +256
   
   u  = x_ero +lx;
   v  = y_ero +ly;
   u2 = x_ero +lx2;
   v2 = y_ero +ly2;
   u3 = x_ero +lx3;
   v3 = y_ero +ly3;

   //r=g=b=0;   
   r_valo=g_valo=b_valo=0;//*bumpptr>>2;

/*   if( !(( u & 0xff00) || ( v & 0xff00)) ) {  
    r_valo += (param1->phongmap[(v<<=8)+u] ) ;    
    g_valo += (param1->phongmap[ v     +u] ) >> 8;    
    b_valo += (param1->phongmap[ v     +u] ) >> 8;    
   }
   if( !((u2 & 0xff00) || (v2 & 0xff00)) ) {  
    g_valo += (param1->phongmap[(v2<<=8)+u2] ) ;    
    r_valo += (param1->phongmap[ v2     +u2] ) >> 8;    
    b_valo += (param1->phongmap[ v2     +u2] ) >> 8;    
   }
   if( !((u3 & 0xff00) || (v3 & 0xff00)) ) {  
    b_valo += (param1->phongmap[(v3<<=8)+u3] ) ;
    r_valo += (param1->phongmap[ v3     +u3] ) >> 8;
    g_valo += (param1->phongmap[ v3     +u3] ) >> 8;     
   }*/
      
/*   if( !(( u & 0xff00) || ( v & 0xff00)) ) {  
    r_valo += (param1->phongmap[(v<<=8)+u] *param1->lights[2]) >> 8;    
    g_valo += (param1->phongmap[ v     +u] *param1->lights[3]) >> 8;    
    b_valo += (param1->phongmap[ v     +u] *param1->lights[4]) >> 8;    
   }
   if( !((u2 & 0xff00) || (v2 & 0xff00)) ) {
    r_valo += (param1->phongmap[(v2<<=8)+u2] *param1->lights[7]) >> 8;    
    g_valo += (param1->phongmap[ v2     +u2] *param1->lights[8]) >> 8;    
    b_valo += (param1->phongmap[ v2     +u2] *param1->lights[9]) >> 8;    
   }
   if( !((u3 & 0xff00) || (v3 & 0xff00)) ) {
    r_valo += (param1->phongmap[(v3<<=8)+u3] *param1->lights[12]) >> 8;
    g_valo += (param1->phongmap[ v3     +u3] *param1->lights[13]) >> 8;
    b_valo += (param1->phongmap[ v3     +u3] *param1->lights[14]) >> 8;
   }*/

   if( !(( u & 0xff00) || ( v & 0xff00)) ) {  
    char pmapvalo = param1->phongmap[(v<<8)+u];
    r_valo += pmapshadet[pmapvalo+valot_256[2]];    
    g_valo += pmapshadet[pmapvalo+valot_256[3]];    
    b_valo += pmapshadet[pmapvalo+valot_256[4]];    
   }
   if( !((u2 & 0xff00) || (v2 & 0xff00)) ) {
    char pmapvalo = param1->phongmap[(v2<<8)+u2];
    r_valo += pmapshadet[pmapvalo+valot_256[7]];    
    g_valo += pmapshadet[pmapvalo+valot_256[8]];    
    b_valo += pmapshadet[pmapvalo+valot_256[9]];    
   }
   if( !((u3 & 0xff00) || (v3 & 0xff00)) ) {
    char pmapvalo = param1->phongmap[(v3<<8)+u3];
    r_valo += pmapshadet[pmapvalo+valot_256[12]];
    g_valo += pmapshadet[pmapvalo+valot_256[13]];
    b_valo += pmapshadet[pmapvalo+valot_256[14]];
   }

//   texel = *pic++;				// texture pixel
//   r = ( (      (texel >> 16)) *r_valo ) >>8;
//   g = ( (0xff &(texel >>  8)) *g_valo ) >>8;
//   b = ( (0xff & texel       ) *b_valo ) >>8;
   
   long r, g, b;
   
   
   if( b_valo & 0xff00) b = picshadet[(*jee)+65280].b;//  pal[(*jee)*3+2];
     else               b = picshadet[(*jee)+(b_valo<<8)].b; //( (*jee++) *b_valo ) >>8;
   if( g_valo & 0xff00) g = picshadet[(*jee)+65280].g;
     else               g = picshadet[(*jee)+(g_valo<<8)].g; //( (*jee++) *b_valo ) >>8;
   if( r_valo & 0xff00) r = picshadet[(*jee)+65280].r;
     else               r = picshadet[(*jee)+(r_valo<<8)].r; //( (*jee++) *b_valo ) >>8;
     
     
     
/*   if( g_valo & 0xff00) g = *jee++;
     else 	        g = ( (*jee++) *g_valo ) >>8;      
   if( r_valo & 0xff00) r = *jee++;
     else               r = ( (*jee++) *r_valo ) >>8;*/
//   b = ( (*jee++) *b_valo ) >>8; g = ( (*jee++) *g_valo ) >>8; r = ( (*jee++) *r_valo ) >>8;
   jee++;

//   if( r & 0xff00) r=255;
//   if( g & 0xff00) g=255;
//   if( b & 0xff00) b=255;
   
   r >>= 3;
   g >>= 2;
   b >>= 3;
   
//   *dest++ = b +(g<<8) +(r<<16);  
   *dest++ = b +(g<<5) +(r<<11);  
   bumpptr++;
   lx++;
   lx2++;
   lx3++;
  }
  dest+=2;
  jee+=2;//*4;
  bumpptr+=2;
  ly++;
  ly2++;
  ly3++;
 } 
 return 0;
}
 
long main(void) {
 
// VBEINFO * vbeinfo = GetVbeInfo();
// if( vbeinfo == NULL ) { cout<<"paska vesa";return 1;}
 VBESURFACE * lfb = SetVbeMode(320,200,16);
 if( lfb == NULL ) { cout<<"eisaa 320x200.15 moodia";return 1;}
 VBESURFACE * dblbuf = setvbedblbuf(lfb);
  
 long loop1, loop2, offset;
 
 short sint[256];
 short cost[256];
 
 for( loop1=0; loop1<256; loop1++) {
  sint[loop1] = sin(3.1415/128.0*loop1)* 96;
  cost[loop1] = cos(3.1415/128.0*loop1)* 96;  
 }
 
// All buffers 64k-aligned !!!
// char * bigbuffer = new char[65536*12];
// char * aligned_bigbuffer = (char *)( (int)(bigbuffer+0xffff) & ~0xffff );

 char * picture    = new char[65536];
 char * phongmap   = new char[65536];
 long * bumpmap    = new long[320*200];
 
 char * greetsit   = new char[160*400];
 char * bk_bumpmap = new char[160*400];

 char * tmpbuffer  = new char[65536];
 long * valot      = new long[8*5]; // valojen x- ja y-coords seka r, g, b
 
 
 loadpcx("timewarp.pcx", picture);
 loadpal_vbe("timewarp.pcx", pal);
 for( loop1=0; loop1<256; loop1++) {
  for( loop2=0; loop2<256; loop2++) {
   picshadet[loop1+loop2*256].r = (pal[loop1*3+0]*loop2)/256;
   picshadet[loop1+loop2*256].g = (pal[loop1*3+1]*loop2)/256;
   picshadet[loop1+loop2*256].b = (pal[loop1*3+2]*loop2)/256;   
  }
 }
 loadpcx("greets2.pcx", phongmap); 

 // 320x200     +--+160x400
 // +--+--+     |1 |
 // |1 |2 | ->  +--+
 // +--+--+     |2 |
 //             +--+
 for(long y=0; y<200; y++) {
  for(long x=0; x<160; x++) {
   greetsit[ y     *160+x] = phongmap[y*320 + x     ];
   greetsit[(y+200)*160+x] = phongmap[y*320 +(x+160)];
  }
 }
 
 loadpcx("tausta.pcx", bk_bumpmap);
 loadpcx("tausta2.pcx", phongmap);
 
 for( loop1=0; loop1<64000; loop1++) {
  long templong = bk_bumpmap[loop1] + phongmap[loop1];
  if( templong>255 ) bk_bumpmap[loop1] = 255;
   else bk_bumpmap[loop1] = templong;
 
  bumpmap[loop1] = 0;
 }

 for(y=0; y<200; y++) {
  for(long x=0; x<80; x++) {
   bumpmap[y*320+x] = bk_bumpmap[y*320+x];
   bumpmap[y*320+x+240] = bk_bumpmap[y*320+x+240];
  }
 }
 
 loadpcx("phongmap.pcx", phongmap);
 
 for(y=0; y<256; y++) {
  for(long x=0; x<256; x++) {
   pmapshadet[y+x*256] = x*y/256;
  }
 }
   
 BUMPSTRUCT jee;
 
 jee.lights = valot;
 jee.number_of_lights = 3;
 jee.phongmap = phongmap;
 jee.bumpmap = bumpmap;
 jee.vbesurf = lfb;
 jee.dest = lfb->ptr32;//dblbuf;
 jee.pic = picture;
 
 unsigned char aste=0;
 long greet_aste=-200;
// vbe_cls(dblbuf->ptr32);
 while( !kbhit() ) {
      
  long temp, x, greets_y=greet_aste;
  long * dest = bumpmap + 80;
  char * src1 = bk_bumpmap +80;
  char * texti = greetsit +(greet_aste<<7)+(greet_aste<<5);
  
  for(y=0; y<200; y++) {
   if( (greets_y<0) || (greets_y>400) ) {
    for( x=0; x<160; x++) {
     *dest++ = *src1++;
    }
    texti+=160;     
   } else {
    for( x=0; x<160; x++) {
     *dest++ = (*src1++) + (*texti++);
    }     
   }   
   dest+=160;
   src1+=160;
   greets_y++;
  }

  vesabump( &jee ); 
  
//  vbe_flip(lfb->ptr4, dblbuf);  
  
  valot[0] = sint[(char)(aste<<1)]+160;
  valot[1] = cost[       aste    ]+100;
  valot[2] = 208;
  valot[3] = 128;
  valot[4] = 128;

  valot[5] = sint[(char)(aste+32)]+160;
  valot[6] = cost[(char)(aste<<1)]+100;
  valot[7] = 128;
  valot[8] = 208;
  valot[9] = 128;

  valot[10] = cost[(char)(aste+96)]+128;
  valot[11] = sint[(char)(aste+96)]+72;   
  valot[12] = 128;
  valot[13] = 128;
  valot[14] = 208;
  
  aste+=2;

  if(greet_aste<400) greet_aste+=1;
   else greet_aste=-200;
 }
 
 CloseVbe(1);
 return 0;
}
