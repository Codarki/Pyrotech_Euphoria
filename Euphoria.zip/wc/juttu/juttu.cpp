#include <stdio.h>
#include <stdlib.h>
#include <iostream.h>
#include <conio.h>

long main() {

    class backbuffer {
    public:
        long xsize,ysize;  // 8byte
        short * ptr;       // 4byte
    };

    backbuffer * bb = new backbuffer[2];

    bb[0].xsize = 320;
    bb[0].ysize = 200;
    bb[0].ptr = new short[ bb[0].xsize*bb[0].ysize ];

    char r = 4;
    char g = 31;    // 5.6.5
    char b = 16;

    bb[0]->ptr[63999] = (r<<11)+(g<<5)+b;

    return 0;
}
