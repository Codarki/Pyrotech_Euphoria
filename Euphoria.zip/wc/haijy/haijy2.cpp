#include <stdio.h>
#include <stdlib.h>
#include <iostream.h>
#include <math.h>
#include <conio.h>
#include "c:\code\wc\ftn\vesa.h"

void flippaa(long * dst, long * src);

//// * P R O C E D U R E S * /////////////////////////////////////////////////

#pragma aux flippaa = \
 "mov ecx,64000"\
 "rep movsd"\
 parm[edi][esi] modify[ecx edi esi];

void main() {
 VBESURFACE * lfb = SetVbeMode(320,200,32);
 if( lfb==NULL ) { cout<<"joku ei toimi"; return;}
 VBESURFACE * dblbuf = setvbedblbuf(lfb);
 
 char st[256], st2[256], st3[256]; 
 char * omax = new char[256*256];
 char * omay = new char[256*256];
// short omax[256];
// short omay[256];
 
 
 for(long i=0; i<256; i++) {
  st[i] = sin(3.1415*i/128.0)*127+128;	// 1 - 255
 } 
 
 char aste  =  20;
 char aste2 =  40;
 char aste3 = 144;
 
 long x,y;

 for( long loop1=0; loop1<256; loop1++) {
  aste  -= 1;
  aste2 += 1;
  aste3  = st[(char)(loop1+1)];
  for( x=0; x<256; x++) {   
   y = st[(char)( x+aste)   ] +st[(char)(x+aste2)] +st[(char)((x+aste3)*2)];
   omax[loop1*256+x] = (y/3)>>1;
   y = st[(char)((x+aste)*2)] +st[(char)(x-aste2)] +st[(char)(x+aste3)    ];
   omay[loop1*256+x] = (y/3)>>1;
  }
 }
 
 aste=0;
 aste2=45;
  
 while( !kbhit() ) {
  
  for( x=0; x<64000; x++) dblbuf->ptr32[x] = 0;
  
  long offset=0;
  short yaste=aste<<8;
  short yaste2=aste<<8;
  short yaste3=aste<<8;
  for( y=0; y<200; y++) {
   short xaste=aste2<<8;
   short xaste2=aste2<<8;
   short xaste3=aste2<<8;
   for( x=0; x<320; x++) {    
    char u = x>>1;
    char v = y>>1;
    char yarvo  = omay[((xaste&0xff00))+v];
    char xarvo  = omax[((yaste&0xff00))+u];
    char yarvo2 = omay[((xaste2&0xff00))+v];
    char xarvo2 = omax[((yaste2&0xff00))+u];
    char yarvo3 = omay[((xaste3&0xff00))+v];
    char xarvo3 = omax[((yaste3&0xff00))+u];
    dblbuf->ptr32[offset+x] = (((yarvo+xarvo))<<16)+(((yarvo2+xarvo2))<<8);//+(((yarvo3+xarvo3)));//(omay[y]);//+(omax[(char)(x)]<<8)+jee;
    xaste +=256;
    xaste2+=192;
    xaste3+=128;   
   }
   offset+=lfb->Width;
   yaste +=256;
   yaste2+=192;
   yaste3+=128;
  }
//  }


  for( y=0; y<256; y++) dblbuf->ptr32[y+(omax[aste*256+(char)(y)])*320] = 0xff;
  for( y=0; y<200; y++) dblbuf->ptr32[y*320+(omax[aste*256+(char)(y)])] = 0xff0000;
//  flippaa(lfb->ptr4, dblbuf->ptr4);
  VbeFlip(lfb, dblbuf);
  
  aste++;
  aste2+=2;
//  aste2 += 1;
//  aste3  = st[(char)(aste+1)];
 }
 
 getch();
 CloseVbe(1);
}

