#include <iostream.h>
#include <stdlib.h>
#include <conio.h>
#include <math.h>
#include "vesa.h"

void Rotate2D32bitVbe( long SinAngle, long CosAngle, VBESURFACE * dst, VBESURFACE * src);
long Smooth32bitVbe( VBESURFACE * dst2, VBESURFACE * dst, VBESURFACE * src );
long Zoom32bitVbe( VBESURFACE * dst, VBESURFACE * src );
void flippaa(long * dst, long * src);

#pragma aux flippaa = \
 "mov ecx,64000"\
 "rep movsd"\
 parm[edi][esi];

long Smooth32bitVbe( VBESURFACE * dst2, VBESURFACE * dst, VBESURFACE * src ) {
  
 for( long i=320; i<64000-320; i++) {

/*         X    7/16 */
/* 3/16   5/16  1/16 */

/*   dst2->ptr4[i] = dst->ptr4[i] = src->ptr4[i] =
                     ((src->ptr4[i    ]>>2) & 0x3f3f3f3f)+
                     ((src->ptr4[i    ]>>2) & 0x3f3f3f3f)+

                  (((((src->ptr4[i-319]>>2) & 0x3f3f3f3f)+
                     ((src->ptr4[i-321]>>2) & 0x3f3f3f3f)+
                     ((src->ptr4[i+319]>>2) & 0x3f3f3f3f)+
                     ((src->ptr4[i+321]>>2) & 0x3f3f3f3f)) >>2)&0x3f3f3f3f)+
                     
                  (((((src->ptr4[i-1  ]>>2) & 0x3f3f3f3f)+
                     ((src->ptr4[i+1  ]>>2) & 0x3f3f3f3f)+
                     ((src->ptr4[i-320]>>2) & 0x3f3f3f3f)+
                     ((src->ptr4[i+320]>>2) & 0x3f3f3f3f)) >>2)&0x3f3f3f3f);*/

   dst2->ptr4[i] = dst->ptr4[i] = src->ptr4[i] =
                  ((src->ptr4[i-321]>>2) & 0x3f3f3f3f)+
   		  ((src->ptr4[i-319]>>2) & 0x3f3f3f3f)+
   		  ((src->ptr4[i+319]>>2) & 0x3f3f3f3f)+
   		  ((src->ptr4[i+321]>>2) & 0x3f3f3f3f);
   
 } 
 return 0;
}

long Zoom32bitVbe( VBESURFACE * dst, VBESURFACE * src ) {
  
  long udelta = 256 * 0.95;
  long vdelta = 256 * 0.95;
  
  long offset=0;
  
  long v=256*100.0 - udelta*100;
  for(long y=0; y<200; y++) {
    long u=256*160 - vdelta*160;
    for(long x=0; x<320; x++) {
      
      dst->ptr4[offset] = src->ptr4[((v&0xff00))+((v>>8)<<6)+(u>>8)];
      
      offset++;
      u+=udelta;      
    }
    v+=udelta;
  }
      
  return 0;
}


/*void Rotate2D32bitVbe( long SinAngle, long CosAngle, VBESURFACE * dst, VBESURFACE * src) {
  short sinang = SinAngle;
  short cosang = CosAngle;
//  long lex = 0;//-(cosang<<8)+(sinang<<7); // left_edge texture-coords
//  long ley = 0;//-(sinang<<8)-(cosang<<7);  
  long lex = -cosang*160 +sinang*100;
  long ley = -sinang*160 -cosang*100;
  long offset=0;
  for( long y=0; y<200; y++) {
    word tx = lex;
    word ty = ley;
    for( long x=0; x<320; x++) {
      byte hmm  = ty>>8;
      byte tmpy = hmm*100/256;//((hmm<<7)+(hmm<<6)+(hmm<<3)) >>8 ;//tmpy=hmm*200/256
      byte hmm2  = tx>>8;
      byte tmpx = hmm2;//*320/256;
      dst->ptr4[offset++] = src->ptr4[ (tmpy<<8)+(tmpy<<6) +(tmpx) ];
      //dblbuf[offset++] = texture[ (tmpy<<8)+(tmpy<<6) +(tx>>8)];
      tx+=cosang;
      ty+=sinang;
    }
    lex-=sinang;
    ley+=cosang;  
  }  
}*/

void Rotate2D32bitVbe( long SinAngle, long CosAngle, VBESURFACE * dst, VBESURFACE * src) {
  long sinang = SinAngle*0.95;
  long cosang = CosAngle*0.95;
//  long lex = 0;//-(cosang<<8)+(sinang<<7); // left_edge texture-coords
//  long ley = 0;//-(sinang<<8)-(cosang<<7);  
  long lex = -160*cosang +100*sinang; 
  long ley = -160*sinang -100*cosang;
  long offset=0;
  for( long y=0; y<200; y++) {
    long tx = lex;
    long ty = ley;
    for( long x=0; x<320; x++) {
//      byte v  = (ty>>16)+100;		// 0 - 256
//      byte u  = (tx>>16)+160;
      unsigned long v  = (ty>>16)+100;		// 0 - 256
      unsigned long u  = (tx>>16)+160;
      //byte vv = (v*200)/256;
      if(v<200 && u<320)
        dst->ptr4[offset++] = src->ptr4[ (v<<8)+(v<<6) +(u) ];
      else dst->ptr4[offset++] = 0;
      
      tx+=cosang;
      ty+=sinang;
    }
    lex-=sinang;
    ley+=cosang;  
  }  
}

long main(void) {
  float * st = new float[65536];
  float * ct = new float[65536];
  
  cout<<st<<endl;
  cout<<ct<<endl;
  
  for( long i=0; i<65536; i++) {
    st[i] = sin(3.14/32768.0*i);
    ct[i] = cos(3.14/32768.0*i);
  }

/*  VBEINFO * vbeinfo = GetVbeInfo();
  if( vbeinfo == NULL ) { cout<<"Ei vesaa!"; return 0; }
  
  
  VBEMODE * modes = GetVbeModes(320,200,32);
  if( modes == NULL ) { cout<<"Ei moodia!"; return 0; }
  
  cout<< (hex) << "Mode " << modes->ModeNum << (dec) << "h: ";
  cout<< modes->Xres << ',' << modes->Yres << ',' << modes->Bits << endl;
  */
    
  VBESURFACE * lfb     = SetVbeMode(320,200,32);
  if( lfb == NULL ) { cout<<"ei saa moodia!"; return 0; }
  
  VBESURFACE * dblbuf  = setvbedblbuf(lfb);
  VBESURFACE * dblbuf2 = setvbedblbuf(lfb);  
    
  for( i=0; i<64000; i++)   dblbuf->ptr4[i] = 0;
  
  long centerx[8];
  long centery[8];
  long rgb[8];
  
  unsigned short aste =0;
  unsigned short aste2=128*256;
  unsigned short aste3=128*256;
  unsigned short astee = 0;
  while( !kbhit() ) {
    
    centerx[0] =  ct[         aste  ]*32  +160;
    centery[0] =  st[(word)(2*aste) ]*16  +100;    
    centerx[1] =  ct[         aste2 ]*16 +160;
    centery[1] =  st[(word)(2*aste2)]*32 +100;
    centerx[2] =  ct[         aste3 ]*-24 +160;
    centery[2] =  st[(word)(2*aste3)]*-48 +100;
    
    centerx[3] =  -ct[(word)(  (word)(aste +94*256)) ]*32  +160;
    centery[3] =  -st[(word)(2*(word)(aste +94*256)) ]*16  +100;    
    centerx[4] =  -ct[(word)(  (word)(aste2+94*256)) ]*16 +160;
    centery[4] =  -st[(word)(2*(word)(aste2+94*256)) ]*32 +100;
    centerx[5] =  -ct[(word)(  (word)(aste3+94*256)) ]*-24 +160;
    centery[5] =  -st[(word)(2*(word)(aste3+94*256)) ]*-48 +100;
    
    
    rgb[0] = 0x000000ff;
    rgb[1] = 0x0000ff00;
    rgb[2] = 0x00ff0000;
    rgb[3] = 0x00ffff00;
    rgb[4] = 0x0000ffff;
    rgb[5] = 0x00ff00ff;
    rgb[6] = 0x00ff3f00;
    rgb[7] = 0x00ff003f;
    
    for(long i=0; i<6; i++) {           
      for( long v=(centery[i]-4)*320 ; v<(centery[i]+4)*320 ; v+=320) {
        for( long u=centerx[i]-5 ; u<centerx[i]+5 ; u++) {        
          dblbuf->ptr4[v +u  ] = rgb[i];
        }
      }
    }
        
//    Zoom32bitVbe(dblbuf2, dblbuf);
    Rotate2D32bitVbe( st[ (word)(st[astee]*8*256) ]*65536.0, ct[ (word)(st[astee]*8*256) ]*65536.0, dblbuf2, dblbuf);    
//    Rotate2D32bitVbe( sin( 3.1415 * (st[astee]*150000.0) /75000.0 )*256, ct[ (word)(st[astee]*256) ]*256, dblbuf2, dblbuf);    
    Smooth32bitVbe(lfb, dblbuf, dblbuf2);
    //flippaa(dblbuf->ptr4, dblbuf2->ptr4);
    //flippaa(lfb->ptr4, dblbuf2->ptr4);
    aste2+=256;
    aste3+=256;
    aste+=256;
    astee+=64;
  }

  getch();
  CloseVbe(1);
  return 0;
}
